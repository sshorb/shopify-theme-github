// -------------------------------------for menu redirection-------------------------------------
$( window ).on("load", function() {
  var get_value = localStorage.getItem("Set_href");  
  var currentUrl = window.location.href;
  var after_split = currentUrl.split('lathene.com')[1];
  console.log(currentUrl)
  console.log(after_split)
  if(after_split == get_value){
     $(".tab-content-block .tab-link").each(function(){
       var ddfdk = $(this).attr('href');
       if(ddfdk == after_split){
         $("#tab1").removeClass('t-active')
         $(this).addClass("t-active")
       }
     })
  }
})

$(document).ready(function(){
   
      $(".tab-content-block .tab-link").click(function(){
        $(".tab-content-block .tab-link").removeClass("t-active")
        // alert("click")
        var get_href = $(this).attr("href");
        localStorage.setItem("Set_href",get_href);
        localStorage.removeItem("Set_btnhref");
      })

    //   var currentUrl = window.location.href;

    // $('.tab-content-block a').each(function(){
    //  var href = $(this).attr('href');
    //     console.log(href); // This will log the href attribute of each anchor tag
    //   // var href = window.location.href
    //   //   $('.tab-link').click(function(){
    //   //   console.log('clickeddd');
    //   //     $(window).load(function(){
    //   //   $(this).addClass('t-active');
    //   //   $('.tab-link').removeClass('t-active');
    //   // })
    //   //     })
    //   var linkUrl = new URL(href, window.location.origin).href;
    //   var matched = false
    //  if(linkUrl === currentUrl){
    //    matched = true;
    //    console.log('matcheeedddddd')
    //     $(this).addClass('t-active');
    //     $('.tab-link').removeClass('t-active');
    //  }
    //    $('.tab-link').click(function(){
    //     console.log('clicked');
    //     $('.tab-link').removeClass('t-active'); // Remove class from all .tab-link elements
    //     $(this).addClass('t-active'); // Add class to the clicked .tab-link element
    // });
    //   $('.tab-link').on('load',function(){
    //      $('.tab-link').removeClass('t-active'); // Remove class from all .tab-link elements
    //     $(this).addClass('t-active'); // Add class to the clicked .tab-link element
    //   })
    // })
  })
// ------------------------------------for button redirection-----------------------------------
$( window ).on("load", function() {
  var get_btnvalue = localStorage.getItem("Set_btnhref");  
  // var currentwindowUrl = window.location.href;
  var commonlink = 'https://lathene.com'
   var currentUrl = window.location.href;
     $('.tab-content-block a').each(function(){
       
    var menulink = commonlink + $(this).attr('href');
       console.log('menulink: ',menulink)
       if(get_btnvalue === menulink){
         console.log('inside if ')
         $('.tab-content-block a').removeClass('t-active');
         $(this).addClass('t-active');
         
       }
  });
  
})

$(document).ready(function(){
  $('.btn-horizontal a').click(function(e){
   
    var commonlink = 'https://lathene.com'
    var btnlink = commonlink + $(this).attr('href');
    localStorage.setItem("Set_btnhref",btnlink);
    localStorage.removeItem("Set_href");
    console.log('btnlink: ',btnlink)
     
  });

})
// ----------------------------for moving previous page redirection-----------------------------------
$( window ).on("load", function() {
  // var get_btnvalue = localStorage.getItem("Set_btnhref");  
  // var currentwindowUrl = window.location.href;
  var commonlink = 'https://lathene.com'
   var currentUrl = window.location.href;
  localStorage.setItem("set_currentUrl",currentUrl);
   localStorage.removeItem("Set_href");
   localStorage.removeItem("Set_btnhref");
     $('.tab-content-block a').each(function(){
        var currentVal = localStorage.getItem("set_currentUrl");  
    var menulink = commonlink + $(this).attr('href');
       console.log('menulink: ',menulink)
       if(currentVal === menulink){
         console.log('inside if ')
         $('.tab-content-block a').removeClass('t-active');
         $(this).addClass('t-active');
         
       }
  });
  
})
// -------------------------------registering account changes----------------------------------------------
$(document).ready(function() {
    // Initially hide the input field container
    $('.option-input').hide();

    // Listen for changes on the select element
    $('.new_select').change(function() {
        // Get the selected option text
        var selectedText = $(this).find('option:selected').text();
        console.log(selectedText, 'optionsssss');
        
        // Check if the selected text is 'Other'
        if (selectedText === 'Other') {
            console.log(selectedText, 'otherrrrr');
            
            // Show the input field if 'Other' is selected and append if it doesn't exist
            if ($('.option-input .other-value').length === 0) {
                $('.option-input').append('<input type="text" placeholder="Enter Here..." class="other-value" name="customer[note][Reference]"/>');
            }
            $('.option-input .other-value').attr('required', true); // Ensure the input field is required
            $('.option-input').show(); // Show the input field container
        } else {
            // Hide the input field if another option is selected
            $('.option-input').hide();
            $('.option-input .other-value').removeAttr('required'); // Remove required attribute
            $('.option-input .other-value').val(''); // Clear the input field
        }
    });
});

